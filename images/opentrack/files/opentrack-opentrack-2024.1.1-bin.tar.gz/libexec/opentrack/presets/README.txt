Here you can add presets as .ini files in order to get them copied for
the end-user as profiles.

Additionally, a preset called 'default.ini' will be sourced into each
profile the user creates.

This functionality exists for hardware vendors who create their custom
distributions of opentrack.

The user can delete the profiles in his 'Documents/opentrack-2.3'
directory. The presets won't be copied again unless their modification
time changes inside the opentrack's distribution.
