The hatire test data is a serial connection dump. One can use it when
debugging hatire, using it in lieu of a real Arduino. There's a
preprocessor #define in hatire that sets a connection dump rather than a
real device.

The data was provided by drdanilov21 on github.

sh
