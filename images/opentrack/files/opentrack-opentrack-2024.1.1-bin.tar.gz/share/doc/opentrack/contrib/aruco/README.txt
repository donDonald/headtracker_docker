Note, the utility only creates .bmp files. Trying to produce a `.png` or jpeg
file will make it error out.
