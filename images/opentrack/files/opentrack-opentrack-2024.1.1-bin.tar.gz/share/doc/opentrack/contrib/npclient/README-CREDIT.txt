The contents of the directory written by one and only, uglyDwarf.

Obtained at epoch time 1412397452 from the mithril-mine's shaft, where
the elite dwarves reside.

For the latest happenings, visit <https://code.google.com/p/linux-track/>
