FaceTrackNoIR for PPJoy 'enabled' games/programs.

FaceTrackNoIR was made compatible with the PPJoy virtual joystick(s), that can be used by various other programs as input. GlovePIE is one of the most powerfull we know (we have also tried tir4fun, but that is quite limited).

To start the PPJoy protocol-server in FaceTrackNoIR, select Virtual Joystick in the 'game-protocol' listbox. The 
settings, necessary to configure PPJoy for FaceTrackNoIR as included in the PPJoy folder.

GlovePIE was made by Carl Kenner and may NOT be used for military purposes. You can download it from the website
http://glovepie.org/glovepie.php

The script FaceTrackNoIR2TrackIR.PIE, which was included in this folder, surves as an example for GlovePIE. If anyone
want to use, change or improve it: feel free to do so. In fact, if you do, we would like to receive a copy :-)

Regards,


The FaceTrackNoIR team:

Wim Vriend
Ron Hendriks



Disclaimer: For usage of 3rd party software like GlovePIE, the FaceTrackNoIR team is not responsible. Use it at your own risk.