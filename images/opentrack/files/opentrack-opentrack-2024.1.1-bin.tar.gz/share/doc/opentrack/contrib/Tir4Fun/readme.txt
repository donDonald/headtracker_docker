What is TIR4FUN?

TIR4FUN is a free utility for dedicated gamers. It enables 6DOF POV control with mouse and joystick axes.

Software is provided as it is. Configuration is straightforward. GUI says it all!

Installation:

Copy all files to a directory. Launch tir4fun.exe to bring up the GUI.
