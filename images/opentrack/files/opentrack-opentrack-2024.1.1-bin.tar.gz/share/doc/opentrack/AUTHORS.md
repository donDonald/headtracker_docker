The following people contributed parts of the codebase to the project, in
chronological order:

- Stanislaw Halik <<sthalik@misaki.pl>>
- Chris Thompson <<mm0zct@gmail.com>>
- Donovan Baarda <<abo@minkirri.apana.org.au>>
- Xavier Hallade <<xavier.hallade@intel.com>>
- Michael Welter <<mw.pub@welter-4d.de>>
- Attila Csipa <<git@csipa.net>>
- Wei Shuai <<cpuwolf@gmail.com>>
- Stéphane Lenclud <<github@lenclud.com>>

See OPENTRACK-LICENSING.txt for licensing information.
